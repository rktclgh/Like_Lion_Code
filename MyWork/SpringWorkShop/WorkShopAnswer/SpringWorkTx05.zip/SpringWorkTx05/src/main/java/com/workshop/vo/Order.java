
package com.workshop.vo;

public class Order {
    private String itemCode;

    public Order(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemCode() {
        return itemCode;
    }
}
