package com.todo.SpringWorkTodoApp07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringWorkTodoApp07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
