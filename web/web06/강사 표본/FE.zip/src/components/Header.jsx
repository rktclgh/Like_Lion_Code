import React from "react";
export default function Header() {
  return (
    <nav className="navbar"> 
      <h1 className="nav--title">나의 여행 일기</h1>
    </nav>
  );
}
