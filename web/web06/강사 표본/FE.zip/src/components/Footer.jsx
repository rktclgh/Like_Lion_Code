import React from "react";

export default function Footer() {
  return (
    <footer className="footer">
      © 2025 나의 여행 일기 프로젝트
    </footer>
  );
}
